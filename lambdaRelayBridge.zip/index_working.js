const LaunchDarkly = require('ldclient-node');
const atob = require('atob');
const DynamoDBFeatureStore = require('ldclient-node-dynamodb-store');
const dynamoDBOptions = { region: process.env.DYNAMO_REGION, accessKeyId: process.env.DYNAMO_ACCESS_KEY, secretAccessKey: process.env.DYNAMO_SECRET_KEY};
const store = DynamoDBFeatureStore('ld-relay', { clientOptions: dynamoDBOptions, prefix:"ld:manuel_demo:production" });
const config = {
    featureStore: store,
    useLdd: true
  };
const ldclient = LaunchDarkly.init(process.env.SDK_KEY, config);

exports.handler = async (event, context, callback) => {
    if (!event.pathParameters.flag) throw('missing flag')
    if (!event.pathParameters.user) throw('missing user')
    
    await ldclient.waitForInitialization();
    
    const flagKey = event.pathParameters.flag || "undefined";
    const userBase64 = event.pathParameters.user;
    const userStr = atob(userBase64);
    const user = JSON.parse(userStr);

    const variation = await ldclient.variation(flagKey, user);
    
    if (variation === undefined) throw('unknown variation')

    ldclient.flush();
    return {"statusCode": 200, "body": variation};
};

